/*
Create and export a module with class "LoginPage".
This class behaves as a Child class, which contains the selectors of Login page UI elements required for the test automation scenarios.
This module can be imported and called from Step Definitions to access the UI elements.
*/

const BasePage = require('./base.page')

class LoginPage extends BasePage {

    get loginPageElement () { return $('div[class="example"] h2') }
    get messageElement () { return $('#flash') }

    open() {
        super.open('https://www.anz.com.au/personal/home-loans/calculators-tools/much-borrow/')
    }
}

module.exports = new LoginPage();