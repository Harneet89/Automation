/*
Create and export a module with class "SecurePage".
This class behaves as a Child class, which contains the selectors of Secure page UI elements required for the test automation scenarios.
This module can be imported and called from Step Definitions to access the UI elements.
*/

const BasePage = require('./base.page')

class SecurePage extends BasePage {

    get applicationType () {return $('//label[@for="application_type_single"]') }
    get yourIncome () {return $('//label[text()="Your income (before tax)"]/..//input') }
    get otherIncome () {return $('//label[text()="Your other income"]/..//input') }
    get livingExpenses () {return $('//label[text()="Living expenses"]/..//input') }
    get currentHomeLoanRepayments () {return $('//label[text()="Current home loan repayments"]/..//input') }
    get otherLoanRepayments () {return $('//label[text()="Other loan repayments"]/..//input') }
    get otherCommitments () {return $('//label[text()="Other commitments"]/..//input') }
    get creditCardLimit () {return $('//label[text()="Total credit card limits"]/..//input') }
    get howMuchToBorrow () {return $('//button[@id="btnBorrowCalculator"]') }


populateForm(){
    
}

}

module.exports = new SecurePage();