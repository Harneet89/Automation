const { Given, When, Then } = require('@cucumber/cucumber');
const LoginPage = require('../pages/login.page');
const SecurePage = require('../pages/secure.page');

  Given('the user is on borrowing calculator page', function () {
    LoginPage.open();
    expect(browser).toHaveTitle('Home loan borrowing power calculator | ANZ');
    console.log("Title is correct");
    
  });

  When('the user enters the data in calculator', function () {
  SecurePage.enterText();
  });

  Then('the user submits the details and validates the capacity', function () {
    SecurePage.submitForm();
    expect(SecurePage.secureAreaElement).toExist();
    expect(SecurePage.secureAreaElement).toHaveTextContaining('Secure Area');

    expect(SecurePage.messageElement).toExist();
    expect(SecurePage.messageElement).toHaveTextContaining(successMessage);
  });